/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package covidjabma;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Admin
 */
public class EnterPrisesTest {
    
    public EnterPrisesTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of Setid method, of class EnterPrises.
     */
    @Test
    public void testSetid() {
        System.out.println("Setid");
        String id = "";
        EnterPrises instance = new EnterPrises();
        instance.Setid(id);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SetName method, of class EnterPrises.
     */
    @Test
    public void testSetName() {
        System.out.println("SetName");
        String Name = "";
        EnterPrises instance = new EnterPrises();
        instance.SetName(Name);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SetLocation method, of class EnterPrises.
     */
    @Test
    public void testSetLocation() {
        System.out.println("SetLocation");
        String Location = "";
        EnterPrises instance = new EnterPrises();
        instance.SetLocation(Location);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Setcountry method, of class EnterPrises.
     */
    @Test
    public void testSetcountry() {
        System.out.println("Setcountry");
        String country = "";
        EnterPrises instance = new EnterPrises();
        instance.Setcountry(country);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SetVaccine method, of class EnterPrises.
     */
    @Test
    public void testSetVaccine() {
        System.out.println("SetVaccine");
        String Vaccine = "";
        EnterPrises instance = new EnterPrises();
        instance.SetVaccine(Vaccine);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SetAddress method, of class EnterPrises.
     */
    @Test
    public void testSetAddress() {
        System.out.println("SetAddress");
        String Address = "";
        EnterPrises instance = new EnterPrises();
        instance.SetAddress(Address);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Getid method, of class EnterPrises.
     */
    @Test
    public void testGetid() {
        System.out.println("Getid");
        EnterPrises instance = new EnterPrises();
        String expResult = "";
        String result = instance.Getid();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetName method, of class EnterPrises.
     */
    @Test
    public void testGetName() {
        System.out.println("GetName");
        EnterPrises instance = new EnterPrises();
        String expResult = "";
        String result = instance.GetName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetLocation method, of class EnterPrises.
     */
    @Test
    public void testGetLocation() {
        System.out.println("GetLocation");
        EnterPrises instance = new EnterPrises();
        String expResult = "";
        String result = instance.GetLocation();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Getcountry method, of class EnterPrises.
     */
    @Test
    public void testGetcountry() {
        System.out.println("Getcountry");
        EnterPrises instance = new EnterPrises();
        String expResult = "";
        String result = instance.Getcountry();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetVaccine method, of class EnterPrises.
     */
    @Test
    public void testGetVaccine() {
        System.out.println("GetVaccine");
        EnterPrises instance = new EnterPrises();
        String expResult = "";
        String result = instance.GetVaccine();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetAddress method, of class EnterPrises.
     */
    @Test
    public void testGetAddress() {
        System.out.println("GetAddress");
        EnterPrises instance = new EnterPrises();
        String expResult = "";
        String result = instance.GetAddress();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
