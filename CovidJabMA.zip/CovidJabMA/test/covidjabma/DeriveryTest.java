/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package covidjabma;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Admin
 */
public class DeriveryTest {
    
    public DeriveryTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of Setid method, of class Derivery.
     */
    @Test
    public void testSetid() {
        System.out.println("Setid");
        String id = "";
        Derivery instance = new Derivery();
        instance.Setid(id);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SetCost method, of class Derivery.
     */
    @Test
    public void testSetCost() {
        System.out.println("SetCost");
        String Cost = "";
        Derivery instance = new Derivery();
        instance.SetCost(Cost);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SetName method, of class Derivery.
     */
    @Test
    public void testSetName() {
        System.out.println("SetName");
        String Name = "";
        Derivery instance = new Derivery();
        instance.SetName(Name);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SetAmount method, of class Derivery.
     */
    @Test
    public void testSetAmount() {
        System.out.println("SetAmount");
        String Amount = "";
        Derivery instance = new Derivery();
        instance.SetAmount(Amount);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SetDerivery method, of class Derivery.
     */
    @Test
    public void testSetDerivery() {
        System.out.println("SetDerivery");
        String Derivery = "";
        Derivery instance = new Derivery();
        instance.SetDerivery(Derivery);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SetEntId method, of class Derivery.
     */
    @Test
    public void testSetEntId() {
        System.out.println("SetEntId");
        String EntId = "";
        Derivery instance = new Derivery();
        instance.SetEntId(EntId);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Getid method, of class Derivery.
     */
    @Test
    public void testGetid() {
        System.out.println("Getid");
        Derivery instance = new Derivery();
        String expResult = "";
        String result = instance.Getid();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetDerivery method, of class Derivery.
     */
    @Test
    public void testGetDerivery() {
        System.out.println("GetDerivery");
        Derivery instance = new Derivery();
        String expResult = "";
        String result = instance.GetDerivery();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetName method, of class Derivery.
     */
    @Test
    public void testGetName() {
        System.out.println("GetName");
        Derivery instance = new Derivery();
        String expResult = "";
        String result = instance.GetName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetCost method, of class Derivery.
     */
    @Test
    public void testGetCost() {
        System.out.println("GetCost");
        Derivery instance = new Derivery();
        String expResult = "";
        String result = instance.GetCost();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetAmount method, of class Derivery.
     */
    @Test
    public void testGetAmount() {
        System.out.println("GetAmount");
        Derivery instance = new Derivery();
        String expResult = "";
        String result = instance.GetAmount();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
