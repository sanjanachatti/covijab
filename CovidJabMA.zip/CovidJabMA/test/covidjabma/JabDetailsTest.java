/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package covidjabma;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Admin
 */
public class JabDetailsTest {
    
    public JabDetailsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setjabname method, of class JabDetails.
     */
    @Test
    public void testSetjabname() {
        System.out.println("setjabname");
        String jabname = "";
        JabDetails instance = new JabDetails();
        instance.setjabname(jabname);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setlocation method, of class JabDetails.
     */
    @Test
    public void testSetlocation() {
        System.out.println("setlocation");
        String location = "";
        JabDetails instance = new JabDetails();
        instance.setlocation(location);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setamount method, of class JabDetails.
     */
    @Test
    public void testSetamount() {
        System.out.println("setamount");
        String amount = "";
        JabDetails instance = new JabDetails();
        instance.setamount(amount);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCost method, of class JabDetails.
     */
    @Test
    public void testSetCost() {
        System.out.println("setCost");
        String Cost = "";
        JabDetails instance = new JabDetails();
        instance.setCost(Cost);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setHosiptal method, of class JabDetails.
     */
    @Test
    public void testSetHosiptal() {
        System.out.println("setHosiptal");
        String Hosiptal = "";
        JabDetails instance = new JabDetails();
        instance.setHosiptal(Hosiptal);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getjabname method, of class JabDetails.
     */
    @Test
    public void testGetjabname() {
        System.out.println("getjabname");
        JabDetails instance = new JabDetails();
        String expResult = "";
        String result = instance.getjabname();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getlocation method, of class JabDetails.
     */
    @Test
    public void testGetlocation() {
        System.out.println("getlocation");
        JabDetails instance = new JabDetails();
        String expResult = "";
        String result = instance.getlocation();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getamount method, of class JabDetails.
     */
    @Test
    public void testGetamount() {
        System.out.println("getamount");
        JabDetails instance = new JabDetails();
        String expResult = "";
        String result = instance.getamount();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCost method, of class JabDetails.
     */
    @Test
    public void testGetCost() {
        System.out.println("getCost");
        JabDetails instance = new JabDetails();
        String expResult = "";
        String result = instance.getCost();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getHosiptal method, of class JabDetails.
     */
    @Test
    public void testGetHosiptal() {
        System.out.println("getHosiptal");
        JabDetails instance = new JabDetails();
        String expResult = "";
        String result = instance.getHosiptal();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getId method, of class JabDetails.
     */
    @Test
    public void testGetId() {
        System.out.println("getId");
        JabDetails instance = new JabDetails();
        int expResult = 0;
        int result = instance.getId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
