/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package covidjabma;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Admin
 */
public class JabRequestTest {
    
    public JabRequestTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of Setid method, of class JabRequest.
     */
    @Test
    public void testSetid() {
        System.out.println("Setid");
        String id = "";
        JabRequest instance = new JabRequest();
        instance.Setid(id);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SetName method, of class JabRequest.
     */
    @Test
    public void testSetName() {
        System.out.println("SetName");
        String Name = "";
        JabRequest instance = new JabRequest();
        instance.SetName(Name);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SetDate method, of class JabRequest.
     */
    @Test
    public void testSetDate() {
        System.out.println("SetDate");
        String Date = "";
        JabRequest instance = new JabRequest();
        instance.SetDate(Date);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SetTime method, of class JabRequest.
     */
    @Test
    public void testSetTime() {
        System.out.println("SetTime");
        String Time = "";
        JabRequest instance = new JabRequest();
        instance.SetTime(Time);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of SetUserId method, of class JabRequest.
     */
    @Test
    public void testSetUserId() {
        System.out.println("SetUserId");
        String UserId = "";
        JabRequest instance = new JabRequest();
        instance.SetUserId(UserId);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Getid method, of class JabRequest.
     */
    @Test
    public void testGetid() {
        System.out.println("Getid");
        JabRequest instance = new JabRequest();
        String expResult = "";
        String result = instance.Getid();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetName method, of class JabRequest.
     */
    @Test
    public void testGetName() {
        System.out.println("GetName");
        JabRequest instance = new JabRequest();
        String expResult = "";
        String result = instance.GetName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetDate method, of class JabRequest.
     */
    @Test
    public void testGetDate() {
        System.out.println("GetDate");
        JabRequest instance = new JabRequest();
        String expResult = "";
        String result = instance.GetDate();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetTime method, of class JabRequest.
     */
    @Test
    public void testGetTime() {
        System.out.println("GetTime");
        JabRequest instance = new JabRequest();
        String expResult = "";
        String result = instance.GetTime();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetUserId method, of class JabRequest.
     */
    @Test
    public void testGetUserId() {
        System.out.println("GetUserId");
        JabRequest instance = new JabRequest();
        String expResult = "";
        String result = instance.GetUserId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
